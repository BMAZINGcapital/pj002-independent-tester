"""PJ002-E006 external trust-adapter gate.

Consumes a normalized trust decision produced outside the subject. It cannot create
or authenticate the adapter itself; positive trust remains impossible without a real
external source and separately validated decision receipt.
"""
from __future__ import annotations
from typing import Any

class E006Error(ValueError): pass

TRUST_REQUIRED={
"event_id","attempt_id","challenge_nonce","clock_domain_identity","evidence_root_identity",
"trust_adapter_identity","trust_adapter_instance_identity","trust_decision",
"decision_reason","decision_receipt_hash","decision_predecessor_hash",
"decision_authentication_reference","decision_binding_digest",
"adapter_source","decision_receipt_authenticated"
}
ANCHOR_REQUIRED={
"event_id","authorized_attempt_id","authorized_challenge_nonce",
"clock_domain_identity","evidence_root_identity"
}

def _out(cid:str,result:str,reason:str)->dict[str,Any]:
    return {"case_id":cid,"result":result,"reason":reason,"verdict_authority":False,
            "admission_authority":False,"limitations":["TRUST_ADAPTER_GATE_ONLY","NATIVE_BEHAVIOR_NOT_PROVEN"]}

def verify(case:dict[str,Any], trust:dict[str,Any], anchor:dict[str,Any])->dict[str,Any]:
    if type(case) is not dict or type(trust) is not dict or type(anchor) is not dict:
        raise E006Error("invalid input")
    cid=case.get("id")
    if case.get("mandatory") is not True or case.get("safety_critical") is not True:
        return _out(cid,"BLOCKED","CASE_WEAKENED")
    if ANCHOR_REQUIRED-set(anchor):
        return _out(cid,"BLOCKED","ANCHOR_INCOMPLETE")
    if TRUST_REQUIRED-set(trust):
        return _out(cid,"BLOCKED","TRUST_RESULT_INCOMPLETE")
    if trust["adapter_source"]=="SUBJECT_GENERATED":
        return _out(cid,"FAIL","SUBJECT_GENERATED_TRUST_RESULT")
    if trust["adapter_source"]=="REPO_LOCAL_ONLY":
        return _out(cid,"FAIL","REPO_LOCAL_ONLY_TRUST_RESULT")
    if trust["event_id"]!="PJ002-E006" or anchor["event_id"]!="PJ002-E006":
        return _out(cid,"BLOCKED","EVENT_BINDING_MISMATCH")
    if trust["attempt_id"]!=anchor["authorized_attempt_id"]:
        return _out(cid,"BLOCKED","ATTEMPT_BINDING_MISMATCH")
    if trust["challenge_nonce"]!=anchor["authorized_challenge_nonce"]:
        return _out(cid,"BLOCKED","CHALLENGE_BINDING_MISMATCH")
    if trust["clock_domain_identity"]!=anchor["clock_domain_identity"]:
        return _out(cid,"BLOCKED","CLOCK_DOMAIN_MISMATCH")
    if trust["evidence_root_identity"]!=anchor["evidence_root_identity"]:
        return _out(cid,"BLOCKED","EVIDENCE_ROOT_MISMATCH")
    if not trust["decision_authentication_reference"] or trust["decision_receipt_authenticated"] is not True:
        return _out(cid,"BLOCKED","TRUST_DECISION_UNAUTHENTICATED")
    decision=trust["trust_decision"]
    if decision=="INVALID_EXTERNAL":
        return _out(cid,"FAIL","EXTERNAL_TRUST_INVALID")
    if decision=="UNKNOWN":
        return _out(cid,"UNKNOWN","EXTERNAL_TRUST_UNKNOWN")
    if decision=="BLOCKED":
        return _out(cid,"BLOCKED","EXTERNAL_TRUST_BLOCKED")
    if decision!="VERIFIED_EXTERNAL":
        raise E006Error("unsupported trust decision")
    return _out(cid,"PASS","VERIFIED_EXTERNAL_TRUST_DECISION_ACCEPTED")

def execute_native(*args:Any,**kwargs:Any)->None:
    raise RuntimeError("CLOSED: E006 requires separate Founder authorization and a real external trust-adapter result")
